#include <iostream>
#include "SchoolManagerSystem.h"
#include "Student.h"

SchoolManagerSystem::SchoolManagerSystem(){
    //Default constructor
    this->courseSize = 0;
    this->studentSize = 0;

    this->_courses = NULL;
    this->_students = NULL;
}
// Copy Constructor
SchoolManagerSystem::SchoolManagerSystem(const SchoolManagerSystem& copy){
    this->courseSize = copy.courseSize; // Copy member variables
    this->studentSize = copy.studentSize;

    this->_courses = new Course[this->courseSize];
    this->_students = new Student[this->studentSize]; 

    for(int i = 0; i < this->courseSize; i++){
        this->_courses[i] = copy._courses[i];
    }   
    for(int i = 0; i < this->studentSize; i++){
        this->_students[i] = copy._students[i];
    }
}

SchoolManagerSystem::~SchoolManagerSystem(){
    //Destructor
    this->courseSize = 0;
    this->studentSize = 0;

    delete [] this->_courses;
    this->_courses = nullptr;

    delete [] this->_students;
    this->_students = nullptr;
}

//GETTERS
int SchoolManagerSystem::getCourseSize() const{
    return courseSize;
}

int SchoolManagerSystem::getStudentSize() const{
    return studentSize;
}


const SchoolManagerSystem& SchoolManagerSystem::operator=(const SchoolManagerSystem& other){
     // Check 
    if((this->_courses == other._courses) && (this->_students == other._students)){
        return other;
    }
    else{
         // Copy member variables
        this->courseSize = other.courseSize;
        this->studentSize = other.studentSize;

        delete [] this->_courses;
        delete [] this->_students;

        this->_courses = new Course[this->courseSize];
        this->_students = new Student[this->studentSize];

        for(int i = 0; i < this->courseSize; i++){
            this->_courses[i] = other._courses[i];
        }

        for(int i = 0; i < this->studentSize; i++){
            this->_students[i] = other._students[i];
        }
    }

    return other;
}

// Function to add a student to the system
void SchoolManagerSystem::add_student(const Student& student){
    // If students exists do not add
    for(int i = 0; i < studentSize; i++){
        if(_students[i] == student){

            return;
        }
    }
    
    // Create a temporary copy of the system and expand the students array
    SchoolManagerSystem temp(*this);
    studentSize++;
    delete [] _students;
    _students = new Student[studentSize];
    for(int i = 0; i < temp.studentSize; i++){
        
        _students[i] = temp._students[i];
    }

    _students[studentSize-1] = student;

}
// Function to add a course to the system
void SchoolManagerSystem::add_course(const Course& course){
    // If course exists do not add
    for(int i = 0; i < courseSize; i++){
        if(_courses[i] == course){

            return;
        }
    }

    SchoolManagerSystem temp(*this);
    courseSize++;
    delete [] _courses;
    _courses = new Course[courseSize];

    for(int i = 0; i < temp.courseSize; i++){
        _courses[i] = temp._courses[i];
    }
    _courses[courseSize-1] = course;
    
}

bool SchoolManagerSystem::delete_student(const Student& student){
    // Search for the student
    for(int i = 0; i < studentSize; i++){

        if(_students[i] == student){
            // Remove student from courses
            for(int j = 0; j < courseSize; j++){
                _courses[j].removeStudent(_students[i]);
            }
             // Create a new array without the deleted student

            Student *temp = new Student[studentSize-1];

            for(int j = 0; j < studentSize; j++){
                if(j==i) continue;
                else if(j > i){
                    temp[j-1] = _students[j];
                }
                else{
                    temp[j] = _students[j];
                }
                
            }            // Delete old array and assign new one
            delete [] _students;
            _students = temp;
            studentSize--;
            return true;
        }
    }
    return false;
}
// Function to delete a course from the system
bool SchoolManagerSystem::delete_course(const Course& course){
    for(int i = 0; i < courseSize; i++){

        if(_courses[i] == course){
            
            //Drop every student who take this course
            for(int j = 0; j < studentSize; j++){
                _students[j].removeCourse(_courses[i]);
            }
            
            Course *temp = new Course[courseSize-1];

            for(int j = 0; j < courseSize; j++){
                if(j==i) continue;
                else if(j > i){
                    temp[j-1] = _courses[j];
                }
                else{
                    temp[j] = _courses[j];
                }
                
            }
            delete [] _courses;
            _courses = temp;
            courseSize--;
            return true;
        }
    }
    return false;
}

void SchoolManagerSystem::drop_selected_student_from_a_course(Student& student){

    Student temp;
    int count = 0;
    int input;
    //Create a temp student object and add the courses that students take

    for(int i = 0; i < studentSize; i++){
        if(_students[i] == student){
            cout << "0 UP" << endl;
            for(int j = 0; j < courseSize; j++){
                for(int k = 0; k < _students[i].getSize(); k++){
                    if(_courses[j] == _students[i][k]){
                        cout << ++count << " " << _students[i][k];
                        temp.addCourse(_students[i][k]);
                    }
                }
            }


            cout << ">> ";
            cin >> input;

            while (cin.fail())
            {
                cin.clear(); 
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << ">> ";
                cin >> input;
            }

            if(input == 0) return;
            else if(input <= count) {
                //Remove the entered course from student and drop the student entered course
                _students[i].removeCourse(temp[input-1]);
                for(int j =0; j < courseSize; j++){
                    if(_courses[j] == temp[input-1]){
                        _courses[j].removeStudent(_students[i]);
                    }
                }
                return;
            }
            else{

                exit(1);
            }
        }
    }


    
}
void SchoolManagerSystem::add_selected_student_to_a_course(Student& student) {
    int input;

    for (int i = 0; i < studentSize; i++) {
        if (_students[i] == student) {
           

            int count = 0;
            for (int j = 0; j < courseSize; j++) {
                bool taken = false;
                for (int k = 0; k < _students[i].getSize(); k++) {
                    if (_courses[j] == _students[i][k]) {
                        taken = true;
                        break;
                    }
                }
                if (!taken) {
                    cout << ++count << ". " << _courses[j] << endl;
                }
            }

            cout << ">> ";
            cin >> input;

            while (cin.fail() || input < 0 || input > count) {
                cout << ">> ";
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cin >> input;
            }

            if (input == 0) {
         
                return;
            }

            Course selectedCourse;
            count = 0;
            for (int j = 0; j < courseSize; j++) {
                bool taken = false;
                for (int k = 0; k < _students[i].getSize(); k++) {
                    if (_courses[j] == _students[i][k]) {
                        taken = true;
                        break;
                    }
                }
                if (!taken && ++count == input) {
                    selectedCourse = _courses[j];
                    break;
                }
            }

            _students[i].addCourse(selectedCourse);

            for (int j = 0; j < courseSize; j++) {
                if (_courses[j] == selectedCourse) {
                    _courses[j].addStudent(_students[i]);
                    break;
                }
            }

  
            return;
        }
    }


}

void SchoolManagerSystem::select_student(const string& name, const string& ID){

    //SELECT STUDENT MENU
    int input;
    Student stu(name, ID);
    bool flag = false;

    for(int i = 0; i < studentSize; i++){
        if(_students[i] == stu){
            flag = true;
            //FLAG for existense of the student
        }  
    } 

    if(flag == false){
        cout << "no student by this name ):" << endl;
        return;
    }

    do{
        cout << "0 up" << endl;
        cout << "1 delete_student" << endl;
        cout << "2 add_selected_student_to_a_course" << endl;
        cout << "3 drop_selected_student_from_a_course" << endl;
        cout << ">> ";
        cin >> input;

        while (cin.fail())
        { 
            cin.clear(); 
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << ">> ";
            cin >> input;
        }


        switch (input)
        {
        case 0:
            //UP
            break;
    
        case 1:
            delete_student(stu);
            //After delete go upper menu
            break;
    
        case 2:
            add_selected_student_to_a_course(stu);
            break;
    
        case 3:
            drop_selected_student_from_a_course(stu);
            break;
    
        default:

            break;
        }

    }while((input!=0) && (input != 1));


    return;
}


void SchoolManagerSystem::list_all_students() const{

    for(int i = 0; i < studentSize; i++){
        cout << i+1 << " " << _students[i];
    }
 
}

void SchoolManagerSystem::list_all_courses() const{

    for(int i = 0; i < courseSize; i++){
        cout << i+1 << " " << _courses[i];
    }

}

void SchoolManagerSystem::select_course(const string& name, const string& code){
    //SELECT COURSE MENU
    int input;
    Course course(name, code);
    bool flag = false;

    for(int i = 0; i < courseSize; i++){
        if(_courses[i] == course){
            flag = true;
            //FLAG for existince of a course
        }  
    } 

    if(flag == false){
        cout << "There isn't such a course!" << endl;
        return;
    }



    for(int i=0; i < courseSize; i++){

        if(_courses[i] == course){

            do{
                cout << "0 up" << endl;
                cout << "1 delete_course" << endl;
                cout << "2 list_students_registered_to_the_selected_course" << endl;
                cout << ">> ";
                cin >> input;

                while (cin.fail())
                {
                    cin.clear(); 
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout << ">> ";
                    cin >> input;
                }


                switch (input)
                {
                case 0:
                    //UP
                    break;
                
                case 1:
                    {
                    delete_course(course);
                    break;
                    }
                case 2:
                    list_students_registered_to_the_selected_course(course);
                    break;
                
                default:

                    break;
                }


            }while((input != 0) && input != 1);

        }

    }

}

void SchoolManagerSystem::list_students_registered_to_the_selected_course(const Course& course) const{

    for(int i = 0; i < courseSize; i++){
        if(_courses[i] == course){
            for(int j = 0; j < _courses[i].getSize(); j++){
                cout << (j+1) << "- " << _courses[i][j];
            }

            return;
        }
        
    }
    cout << "THERE ISN'T SUCH A COURSE" << endl;

}
