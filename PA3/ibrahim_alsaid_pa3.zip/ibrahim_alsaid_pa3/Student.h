#ifndef STUDENT_H
#define STUDENT_H

#pragma once

#include <iostream>
#include <string.h>
#include "Course.h"
#include <limits>

using namespace std;


class Student{

	string name; // Student Name
        string ID; // Student ID number
        Course* courses; // Course that student takes
        int _size; //Courses Size

    public:
        Student();
        Student(const string& name, const string& ID);
        Student(const Student& copy);
        ~Student();
  	void setName(const string& name);
        void setID(const string& ID);
        string getName() const;
        string getID() const;
        int getSize() const;

        const Student& operator=(const Student& other);
        friend ostream& operator<<(ostream& os, const Student& stu);
        bool operator==(const Student& other);
        bool operator!=(const Student& other);
        Course& operator[](const int& index) const;
        void addCourse(const Course& other); // Add new course to the dynamic array.
        bool removeCourse(const Course& other); // delete the course from dynamic array if it is exists.
       

};



#endif //STUDENT_H
