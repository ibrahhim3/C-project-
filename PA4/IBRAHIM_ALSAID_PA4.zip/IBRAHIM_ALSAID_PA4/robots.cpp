#include <iostream>
#include <string>
#include "robots.h"

using namespace std;


Robot::Robot() : moved(false), fought(false) {}

Robot::Robot(int counter, int newType, int newStrength, int newHit, string name) : moved(false), fought(false),
                                                                                   type(newType), strength(newStrength),
                                                                                   hitpoints(newHit),
                                                                                   name(name + "_" + to_string(counter)) {}

Robot:: ~Robot() {
   
}

string Robot::getType() { 
    switch (type) {
    case 0:
        return "optimusprime";
    case 1:
        return "robocop";
    case 2:
        return "roomba";
    case 3:
        return "bulldozer";
    case 4:
        return "kamikaze";
    }
    return "??";
}

int Robot::getDamage() {
    if (type == 4) {//kamikaze
        int damage = hitpoints; // kamikaze inflicts damage equal to its hitpoints
        cout << name << " attacks for " << damage << " points!" << endl;
        // set the hitpoint to 0 to treat it as dead 
        set_the_hitpoint(0);     
        return damage;
    }
    int damage = (rand() % strength) + 1;
    cout <<name << " attacks for " << damage << " points!" << endl;
    if (type == 2) {//if roomba
        int damage2 = (rand() % strength) + 1;
        cout<<"ohhhh " << name<< " attacks again for " << damage2 << " points!" << endl;
        damage += damage2;
    }
    
    return damage;
}

bool Robot::fight(Robot* opponent) {
    while (true) {
         // attacker (this robot) attacks first
        int damage_attacker = getDamage();
        cout << name << "(" << hitpoints << ")" << " hits " << opponent->name << "(" << opponent->hitpoints << ")" << " with " << damage_attacker << endl;
        opponent->dec_the_hitpo(damage_attacker); // hitpoints of S decremented by d_r
        cout << "The new hitpoints of " << opponent->name << " " << opponent->hitpoints << endl;

        // check if opponent is dead
        if (opponent->get_the_hitpoint() <= 0) {
            fought = true; // Set fought flag for attacker
            cout << opponent->getName() << " is dead" << endl << endl;
            return true; //attacker wins
        }
        // opponent attacks back
        int damage_victim = opponent->getDamage();
        cout << opponent->name << "(" << opponent->hitpoints << ")" << " hits " << name << "(" << hitpoints << ")" << " with " << damage_victim << endl;
        dec_the_hitpo(damage_victim); // hitpoints of robot decremented by d_s
        cout << "The new hitpoints of " << name << " " << hitpoints << endl;

        // if R is dead opponent wins
        if (get_the_hitpoint() <= 0) {
            cout << getName() << " is dead" << endl;
            break; 
        }
    }
    cout << endl;
    return false;
}


int Robot::get_the_hitpoint(){
    return this->hitpoints;
}

string Robot::getName() {
    return this->name;
}

bool Robot::getmove() {
    return this->moved;
}

bool Robot::get_the_fight() {
    return this->fought;
}

void Robot::setMoved(bool moved) {
    this->moved = moved;
}

void Robot::setFight(bool fought){ 
    this->fought = fought;
}

void Robot::set_the_hitpoint(int new_hitpoint) {
    this->hitpoints = new_hitpoint;
}

bool Robot::isDead(){
    return hitpoints <= 0;
}

void Robot::dec_the_hitpo(int d_r) {
    hitpoints -= d_r;
}

