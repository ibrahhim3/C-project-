#include <iostream>
#include <string>
#include <time.h>
#include "robots.h"
#include "world.h"

class Roomba : public Robot {
public:
    Roomba() {}
    Roomba(int counter,int newType, int newStrength, int newHit, string name):Robot(counter,newType, newStrength, newHit, name) {}
    ~Roomba() {}
    int getDamage() { return Robot::getDamage();}
    string getType() { return "roomba"; }

};

class Bulldozer : public Robot {
public:
    Bulldozer() {}
    Bulldozer(int counter,int newType, int newStrength, int newHit, string name) :Robot(counter,newType, newStrength, newHit, name) {}
    ~Bulldozer() {}
    int getDamage() { return Robot::getDamage();}
    string getType(){ return "bulldozer"; }

};

class Kamikaze : public Robot {
public:
    Kamikaze() {}
    Kamikaze(int counter, int newType, int newStrength, int newHit, string name) : Robot(counter, newType, newStrength, newHit, name) {}
    ~Kamikaze() {}
    int getDamage(){
        return Robot::getDamage();
    }
    string getType() { return "kamikaze"; }
};


class Humanic : public Robot {

public:
    Humanic() {}
    Humanic(int counter,int newType, int newStrength, int newHit, string name) :Robot(counter,newType, newStrength, newHit, name) {}
    ~Humanic() {}
    int getDamage() {
        int damage = Robot::getDamage(); 
        if (rand() % 10 == 0) { //the robot has a 10% chance to get extra 50 
            damage += 50;
            cout << "the robot has just got 50 damage extra " << endl;
        }
        if (type == 0 &&( rand() % 15 == 0)) { //With a 15% chance "optimusprime" robots inflict a strong attack that doubles the normal amount of damage
            damage *= 2;
            cout << "2X damage " << endl;
        }

        return damage;
    }

};

class Optimusprime : public Humanic {
public:
    Optimusprime() {};
    Optimusprime(int counter,int newType, int newStrength, int newHit, string name) :Humanic(counter,newType, newStrength, newHit, name) {}
    ~Optimusprime() {}
    int getDamage() { return Humanic::getDamage(); }
    string getType() { return "optimusprime"; }

};

class Robocop : public Humanic {
public:
    Robocop() {}
    Robocop(int counter,int newType, int newStrength, int newHit, string name):Humanic(counter,newType, newStrength, newHit, name) {}
    ~Robocop() {}
    int getDamage() { return Humanic::getDamage(); }
    string getType() { return "robocop"; }

};

const int OPTIMUSPRIME_TYPE = 0;
const int OPTIMUSPRIME_STRENGTH = 100;
const int OPTIMUSPRIME_HITPOINTS = 100;

const int ROBOCOP_TYPE = 1;
const int ROBOCOP_STRENGTH = 30;
const int ROBOCOP_HITPOINTS = 40;

const int ROOMBA_TYPE = 2;
const int ROOMBA_STRENGTH = 3;
const int ROOMBA_HITPOINTS = 10;

const int BULLDOZER_TYPE = 3;
const int BULLDOZER_STRENGTH = 50;
const int BULLDOZER_HITPOINTS = 200;

const int KAMIKAZE_TYPE = 4;
const int KAMIKAZE_STRENGTH = 10;
const int KAMIKAZE_HITPOINTS = 10;


int main() {
    int counter = 0;
    int inital = 5;
    srand(time(NULL));
    World w;
    //to set 5 Optimusprime
    while (counter<inital) {
        int x = rand() % 10;
        int y = rand() % 10;
        if (w.getAt(x,y)==NULL) {
            Optimusprime* o = new Optimusprime(counter, OPTIMUSPRIME_TYPE, OPTIMUSPRIME_STRENGTH, OPTIMUSPRIME_HITPOINTS, "optimusprime");
            w.setAt(x, y, o);
            counter++;
        }
    }
    // to set 5 robocop 
    counter = 0;
    while (counter < inital) {
        int x = rand() % 10;
        int y = rand() % 10;
        if (w.getAt(x, y) == NULL) {
            Robocop* R = new Robocop(counter, ROBOCOP_TYPE, ROBOCOP_STRENGTH, ROBOCOP_HITPOINTS, "robocop");
            w.setAt(x, y, R);
            counter++;
        }
    }
    // to set 5 Roomba
    counter = 0;
    while (counter < inital) {
        int x = rand() % 10;
        int y = rand() % 10;
        if (w.getAt(x, y) == NULL) {
            Roomba* r = new Roomba(counter, ROOMBA_TYPE, ROOMBA_STRENGTH, ROOMBA_HITPOINTS, "roomba");
            w.setAt(x, y, r);
            counter++;
        }
    }
    // to set 5 Bulldozer
    counter = 0;
    while (counter < inital) {
        int x = rand() % 10;
        int y = rand() % 10;
        if (w.getAt(x, y) == NULL) {
            Bulldozer* B = new Bulldozer(counter, BULLDOZER_TYPE, BULLDOZER_STRENGTH, BULLDOZER_HITPOINTS, "bulldozer");
            w.setAt(x, y, B);
            counter++;
        }
    }

    //to set 5 kamikaze   
    counter = 0;
    while (counter < inital) {
        int x = rand() % 10;
        int y = rand() % 10;
        if (w.getAt(x, y) == NULL) {
            Kamikaze* k = new Kamikaze(counter, KAMIKAZE_TYPE, KAMIKAZE_STRENGTH, KAMIKAZE_HITPOINTS, "kamikaze");
            w.setAt(x, y, k);
            counter++;
        }
    }

    while (true) {
       //w.print();
      // cout << "\n";
        w.SimulateOneStep();
        if (w.gameOver()) {
            w.print_the_winner();
            break;
        }
    }


    return 0;

} 
