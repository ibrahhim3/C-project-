#ifndef WORLD_H_
#define WORLD_H_
#include "robots.h"

using namespace std;
class Robot;
const int grid_size = 10; //10x10
class World {
    friend class Robot;// allow Robot to access the grid
public:
    World();
    ~World();
    Robot* getAt(int x,int y);
    void setAt(int x, int y, Robot* org); //to set the (x,y) 
    void print(); // printing The ring 
    void SimulateOneStep(); 
    bool isEmpty(int x,int y); // to check the index x,y empty or not 
    bool move(int x, int y);  
    bool gameOver();
    void print_the_winner();
    Robot* grid[grid_size][grid_size];
private:
    static int ropot_counter; // to trace the number of the robots until remain just one
};

#endif