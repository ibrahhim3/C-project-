#ifndef ROBOTS_H_
#define ROBOTS_H_
#include "world.h"

using namespace std;

class Robot {
public:
    Robot();
    Robot(int counter,int newType, int newStrength, int newHit, string name);
    virtual ~Robot();
    virtual string getType() = 0; // abstract 
    virtual int getDamage(); // virtual 
    int get_the_hitpoint();
    string getName();
    bool getmove();
    bool get_the_fight();
    void setFight(bool fought);
    void setMoved(bool moved);
    void set_the_hitpoint(int new_hitpoint);
    bool isDead(); //checking if it's dead 
    void dec_the_hitpo(int d_r); // decreasing the hitpoint
    bool fight(Robot* opponent); 

protected:
    int type; 
    string name;
    int strength;
    int hitpoints;
    bool moved; //true moved false not moved
    bool fought; //true robot fought false robot not fought
};


#endif