#include <iostream>
#include "world.h"

using namespace std;


int World::ropot_counter = 0;// initializing the static variable

World::World() { // default constructor filling the indexes by null
    for (int i = 0; i < grid_size; i++) {
        for (int j = 0; j < grid_size; j++) {
            grid[i][j] = NULL;
        }
    }
}

World:: ~World() { //destructor
    for (int i = 0; i < grid_size; i++) {
        for (int j = 0; j < grid_size; j++) {
            delete grid[i][j];
        }
    }
}

Robot* World::getAt(int x,int y) {
    if ((x >= 0) && (x < grid_size) && (y >= 0) && (y < grid_size)) { 
        return grid[x][y];
    }
    return NULL;
}



void World::setAt( int x,  int y, Robot* org) {
    if ((x >= 0) && (x < grid_size) && (y >= 0) && (y < grid_size)) {
        grid[x][y] = org;
    }
    ropot_counter++; // increase the number of the robots 
}


void World::print() {// for print the ring with the fighters 
    for (int i = 0; i < grid_size; i++) {
        for (int j = 0; j < grid_size; j++) { 
            if (grid[i][j] == NULL) {
                cout << ".";
            }
            else if (grid[i][j]->getType() == "optimusprime") {
                cout << "O";
            }
            else if (grid[i][j]->getType() == "robocop") {
                cout << "R";
            }
            else if (grid[i][j]->getType() == "roomba") {
                cout << "r";
            }
            else if (grid[i][j]->getType() == "bulldozer") {
                cout << "B";
            }
            else {
                cout << "K";
            }
        }
        cout << endl;
    }
}

bool World::isEmpty( int x,  int y) {
    if (grid[x][y] == NULL) {
        return true;
    }
    else
        return false;
}


bool World::move(int x, int y) {
    int dx = 0, dy = 0;
    while (true) {
        int direction = rand() % 4;
        switch (direction) {
        case 0: dx = 0; dy = 1; break;  // right
        case 1: dx = 0; dy = -1; break; // left
        case 2: dx = -1; dy = 0; break; // up
        case 3: dx = 1; dy = 0; break;  // down
        }
        int new_x = x + dx;
        int new_y = y + dy;
        if (new_x >= 0 && new_x < grid_size && new_y >= 0 && new_y < grid_size) {
            // check if the destination cell is empty
            if (isEmpty(new_x, new_y)) {
                grid[new_x][new_y] = grid[x][y];
                grid[x][y] = NULL;//make the prev indexes NULL
                return false; // no fight
            }
            else {
                // fight
                if (grid[x][y]->fight(grid[new_x][new_y])) {
                    grid[new_x][new_y] = grid[x][y];
                }
                grid[x][y] = NULL;
                ropot_counter--;
                return true; 
            }
        }
    }
}

void World::SimulateOneStep() {
    // reset the 'moved' and 'fought' flags for all objects in the grid
    for (int i = 0; i < grid_size; i++) {
        for (int j = 0; j < grid_size; j++) {
            if (grid[i][j] != NULL) { 
                grid[i][j]->setMoved(false);
                grid[i][j]->setFight(false);
            }
        }
    }
    bool movementOccurred = false; // flag to keep track of whether any movement occurred in this step

    // loop over each cell in the grid to find robot that haven't moved or fought
    for (int i = 0; i < grid_size; i++) {
        for (int j = 0; j < grid_size; j++) {
            // if a cell is not empty and the object in the cell hasn't moved and hasn't fought
            if (grid[i][j] != NULL && !grid[i][j]->getmove() && !grid[i][j]->get_the_fight()) {
                move(i, j); // move the robot
                movementOccurred = true; // update movement flag
            }
        }
    }
    // to make sure all the robot has moved 
    if (!movementOccurred) {
        for (int i = 0; i < grid_size; i++) {
            for (int j = 0; j < grid_size; j++) {
                // if a cell is not empty and the object in the cell hasn't moved
                if (grid[i][j] != NULL && !grid[i][j]->getmove()) {
                    // move the object in the cell
                    move(i, j);
                }
            }
        }
    }
}

bool World::gameOver() { //if there is just one robot return true 
  
    if (ropot_counter ==1) {
        return true;
    }
    else
        return false;
}

void World::print_the_winner() { 
    for (int i = 0; i < grid_size; i++) {
        for (int j = 0; j < grid_size; j++) {
            if (grid[i][j] != NULL) {// looping until you reach the robot then gets its name 
                cout << grid[i][j]->getName() << " is the winner" << endl;
                break;
            }
        }
    }
}