#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <stdexcept>
#include <unordered_map>          
using namespace std;
// class representing the structure of the catalog
class The_Catalog {
public:
    vector<string> fieldNames;
    vector<string> fieldTypes;
    vector<string> isArray; // single or multi
};
// class representing a catalog entry
class CatalogEntry {
public:
    vector<string> single;
    vector<vector<string>> multi;

    CatalogEntry(const vector<string>& singleFields, const vector<vector<string>>& multiFields)
        : single(singleFields), multi(multiFields) {}
};
// to get the format 
The_Catalog parseFormat(const string& line) {
    The_Catalog entry;
    stringstream ss(line);
    string descriptor;
    while (getline(ss, descriptor, '|')) {
        istringstream iss(descriptor);
        string fieldName, fieldType, isArray;
        getline(iss, fieldName, ':');
        getline(iss, fieldType, ':');
        getline(iss, isArray, ':');
        entry.fieldNames.push_back(fieldName);
        entry.fieldTypes.push_back(fieldType);
        entry.isArray.push_back(isArray);
    }
    return entry;
}
//to get the entry 
CatalogEntry parseEntry(const string& line, const The_Catalog& formatDescriptor) {
    vector<string> singleFields;
    vector<vector<string>> multiFields;
    stringstream ss(line);
    string field;

    for (size_t i = 0; i < formatDescriptor.fieldNames.size(); ++i) {
        if (getline(ss, field, '|')) {
            if (formatDescriptor.isArray[i] == "single") {
                singleFields.push_back(field);
                multiFields.emplace_back(); // add an empty vector 
            }
            else if (formatDescriptor.isArray[i] == "multi") {
                vector<string> multiField;
                stringstream multiStream(field);
                string value;
                while (getline(multiStream, value, ':')) {
                    multiField.push_back(value);
                }
                multiFields.push_back(multiField);
                singleFields.push_back(""); // add an empty string 
            }
        }
    }

    if (singleFields.size() != formatDescriptor.fieldNames.size()) {
        // exception: missing field
        throw runtime_error("Exception: missing field");
    }

    return CatalogEntry(singleFields, multiFields);
}

// Parse catalog data file
vector<CatalogEntry> parseCatalog(const string& filename, The_Catalog& formatDescriptor, ofstream& outputFile) {
    ifstream file(filename);
    if (!file.is_open()) {
        throw runtime_error("Error: Unable to open data file");
    }

    vector<CatalogEntry> catalogData;
    unordered_map<string, bool> entryMap;
    string line;
    bool isFirstLine = true;

    while (getline(file, line)) {
        try {
            if (isFirstLine) {
                formatDescriptor = parseFormat(line);
                for (const auto& fieldName : formatDescriptor.fieldNames) { // to print the format
                    outputFile << fieldName << "|";
                }
                outputFile << endl;
                isFirstLine = false;
            }
            else {
                CatalogEntry entry = parseEntry(line, formatDescriptor);

                // check for duplicate entry 
                string key = entry.single[0];
                if (entryMap.find(key) != entryMap.end()) {
                    // log exception: duplicate entry
                    throw runtime_error("Exception: duplicate entry");
                }

                entryMap[key] = true;
                catalogData.push_back(entry);
            }
        }
        catch (const runtime_error& e) {
            outputFile << e.what() << "\n" << line << endl;
        }
    }
    file.close();
    return catalogData;
}

// log catalog read operation
void unique(const The_Catalog& formatDescriptor, const vector<CatalogEntry>& catalog, ofstream& outputFile) {
    if (outputFile.is_open()) {
        // Print number of unique entries
        outputFile << catalog.size() << " unique entries" << endl;
    }
    else {
        cout << "Error: Unable to write catalog read to output file" << endl;
    }
}
// Sort catalog entries based on a field
void sortCatalog(vector<CatalogEntry>& catalog, const string& fieldName, const The_Catalog& formatDescriptor) {
    size_t fieldIndex = 0;
    for (size_t i = 0; i < formatDescriptor.fieldNames.size(); ++i) {
        if (formatDescriptor.fieldNames[i] == fieldName) {
            fieldIndex = i;
            break;
        }
    }

    if (formatDescriptor.isArray[fieldIndex] == "single") {
        sort(catalog.begin(), catalog.end(), [&](const CatalogEntry& a, const CatalogEntry& b) {
            return a.single[fieldIndex] < b.single[fieldIndex];
            });
    }
    else {
        sort(catalog.begin(), catalog.end(), [&](const CatalogEntry& a, const CatalogEntry& b) {
            return a.multi[fieldIndex] < b.multi[fieldIndex];
            });
    }
}
// Search catalog entries based on value and field
vector<CatalogEntry> searchCatalog(const vector<CatalogEntry>& catalog, const string& value, const string& field, const The_Catalog& formatDescriptor, ofstream& outputFile) {
    vector<CatalogEntry> matchedEntries;
    int fieldIndex = -1;
    for (size_t i = 0; i < formatDescriptor.fieldNames.size(); ++i) {
        if (formatDescriptor.fieldNames[i] == field) {
            fieldIndex = i;
            break;
        }
    }

    if (fieldIndex == -1) {
        throw runtime_error("Exception: command is wrong");
    }

    for (const auto& entry : catalog) {
        if (formatDescriptor.isArray[fieldIndex] == "single") {
            if (entry.single[fieldIndex].find(value) != string::npos) {
                matchedEntries.push_back(entry);
            }
        }
        else {
            for (const auto& val : entry.multi[fieldIndex]) {
                if (val.find(value) != string::npos) {
                    matchedEntries.push_back(entry);
                    break;
                }
            }
        }
    }
    return matchedEntries;
}
// log command output
void command_output(const string& command, const vector<CatalogEntry>& output, const The_Catalog& formatDescriptor, ofstream& outputFile) {
    if (outputFile.is_open()) {
        outputFile << command << endl;
        for (const auto& entry : output) {
            for (size_t i = 0; i < formatDescriptor.fieldNames.size(); ++i) {
                if (formatDescriptor.isArray[i] == "single") {
                    outputFile << entry.single[i] << "|";
                }
                else {
                    for (const auto& val : entry.multi[i]) {
                        outputFile << val;
                        if (&val != &entry.multi[i].back()) {
                            outputFile << ":";
                        }
                    }
                    outputFile << "|";
                }
            }
            outputFile << endl;
        }
    }
    else {
        cout << "Error: Unable to write command output to output file" << endl;
    }
}
// execute commands from a file
void executeCommands(const string& filename, vector<CatalogEntry>& catalog, const The_Catalog& formatDescriptor, ofstream& outputFile) {
    ifstream file(filename);
    if (!file.is_open()) {
        throw runtime_error("Error: Unable to open commands file");
    }

    string line;
    while (getline(file, line)) {
        try {
            stringstream ss(line);
            string command;
            ss >> command;

            if (command == "search") {
                string value, in, field;
                ss >> value >> in >> field;
                value = value.substr(1, value.size() - 2);
                field = field.substr(1, field.size() - 2);

                if (in != "in") {
                    throw runtime_error("Exception: command is wrong");
                }

                vector<CatalogEntry> searchResult = searchCatalog(catalog, value, field, formatDescriptor, outputFile);
                command_output(line, searchResult, formatDescriptor, outputFile);

            }
            else if (command == "sort") {
                string field_name;
                ss >> field_name;
                field_name = field_name.substr(1, field_name.size() - 2);

                sortCatalog(catalog, field_name, formatDescriptor);
                command_output(line, catalog, formatDescriptor, outputFile);

            }
            else {
                throw runtime_error("Exception: command is wrong");
            }
        }
        catch (const runtime_error& e) {
            outputFile << e.what() << "\n" << line << endl;
        }
    }
    file.close();
}

int main() {
    ofstream outputFile("output.txt");
    if (!outputFile.is_open()) {
        cout << "Error: Unable to open output file" << endl;
        return 1;
    }

    try {
        The_Catalog formatDescriptor;
        vector<CatalogEntry> catalog = parseCatalog("data.txt", formatDescriptor, outputFile);
        unique(formatDescriptor, catalog, outputFile);
        executeCommands("commands.txt", catalog, formatDescriptor, outputFile);

    }
    catch (const runtime_error& e) {
        outputFile << e.what() << endl;
    }

    outputFile.close();
    return 0;
}

