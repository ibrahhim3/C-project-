#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include<string>
#include "SparseVector.h"

struct Element {

    int index;
    double value;
    int row;

};
class SparseMatrix {
private:
    vector<vector<Element>> matrix; //vectore<vector> the same as 2D  

public:

    SparseMatrix() {};

    SparseMatrix(const string& filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cerr << "Failed to open file: " << filename << endl;
            return;
        }

        string line;
        while (getline(file, line)) {
            istringstream iss(line);
            int rowIndex;
            iss >> rowIndex;
            if (rowIndex >= matrix.size()) {
                matrix.resize(rowIndex + 1);
            }

            Element element;
            element.row = rowIndex; // store the row index in the element

            char separator;
            while (iss >> element.index >> separator >> element.value) {
                if (element.value != 0) { // to check if the value is not 0
                    matrix[rowIndex].push_back(element);
                }
            }
        }

        file.close();
    }

    SparseMatrix operator+(const SparseMatrix& other) const {
        SparseMatrix result(*this); // create a copy of the current matrix

        for (size_t i = 0; i < other.matrix.size(); ++i) {
            for (const Element& element : other.matrix[i]) {
                // find the corresponding row in the result matrix
                size_t rowIndex = element.row;

                // check if the row index is within the bounds of the result matrix
                if (rowIndex >= result.matrix.size()) {
                    result.matrix.resize(rowIndex + 1);
                }

                // check if the current element's index already exists in the result matrix's row
                bool found = false;
                for (Element& resultElement : result.matrix[rowIndex]) {
                    if (resultElement.index == element.index) {
                        resultElement.value += element.value; // cdd the value to the existing element
                        found = true;
                        break;
                    }
                }

                // if the index is not found, add the element to the result matrix
                if (!found) {
                    result.matrix[rowIndex].push_back(element);
                }
            }
        }

        return result;
    }



    SparseMatrix operator-(const SparseMatrix& other) const {
        SparseMatrix result(*this); // create a copy of the current matrix

        for (size_t i = 0; i < other.matrix.size(); ++i) {
            for (const Element& element : other.matrix[i]) {
                // find the corresponding row in the result matrix
                size_t rowIndex = element.row;

                // check if the row index is within the bounds of the result matrix
                if (rowIndex >= result.matrix.size()) {
                    result.matrix.resize(rowIndex + 1);
                }

                // check if the current element's index already exists in the result matrix's row
                bool found = false;
                for (Element& resultElement : result.matrix[rowIndex]) {
                    if (resultElement.index == element.index) {
                        resultElement.value -= element.value; // subtract the value from the existing element
                        found = true;
                        break;
                    }
                }

                // if the index is not found, add the negative of the element to the result matrix
                if (!found) {
                    Element negativeElement = { element.index, -element.value, rowIndex };
                    result.matrix[rowIndex].push_back(negativeElement);
                }
            }
        }

        return result;
    }

    SparseMatrix operator-() {
        SparseMatrix negatedMatrix;
        negatedMatrix.matrix.resize(matrix.size()); // resize the matrix vector

        for (size_t i = 0; i < matrix.size(); ++i) {
            for (const Element& element : matrix[i]) {
                Element negatedElement = { element.index, -element.value, element.row };
                negatedMatrix.matrix[i].push_back(negatedElement);
            }
        }

        return negatedMatrix;
    }


    SparseMatrix& operator=(const SparseMatrix& other) {
        // check for self-assignment
        if (this != &other) {
            // clear the current matrix data
            matrix.clear();

            // resize the matrix vector to match the size of the other matrix
            matrix.resize(other.matrix.size());

            // perform a deep copy of the matrix data
            for (size_t i = 0; i < other.matrix.size(); ++i) {
                for (const Element& element : other.matrix[i]) {
                    Element copiedElement = { element.index, element.value, element.row };
                    matrix[i].push_back(copiedElement);
                }
            }
        }
        return *this;
    }



 friend ostream& operator<<(ostream& os, const SparseMatrix& matrix) {
    for (size_t i = 0; i < matrix.matrix.size(); ++i) {
        if (!matrix.matrix[i].empty()) {
            os << i + 1 << " ";
            for (const Element& element : matrix.matrix[i]) {
                os << element.index << ":" << element.value << " ";
            }
            os << std::endl;
        }
    }
    return os;
}

    SparseMatrix operator*(const SparseMatrix& other) const {
        SparseMatrix result;

        // Resize the result matrix to the maximum of the two input matrices
        size_t maxRows = std::max(matrix.size(), other.matrix.size());
        result.matrix.resize(maxRows);

        // Loop through each row of the first matrix
        for (size_t i = 0; i < matrix.size(); ++i) {
            // Loop through each element of the current row
            for (const Element& element : matrix[i]) {
                int index = element.index;
                double value = element.value;

                // Find the corresponding row in the second matrix
                if (i < other.matrix.size()) {
                    // Loop through each element in the corresponding row of the second matrix
                    for (const Element& otherElement : other.matrix[i]) {
                        // If the indices match, multiply the values
                        if (otherElement.index == index) {
                            Element productElement = { index, value * otherElement.value, i };
                            result.matrix[i].push_back(productElement);
                        }
                    }
                }
            }
        }

        return result;
    }

};
