#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include<string>
using namespace std;

struct val {
    int index;
    double value;
};

class SparseVector {
private:
    vector<val> alldata;
public:
    SparseVector() {} // default constructor

    SparseVector(string filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cout << "Error openingg file " << filename << endl;
            return;
        }
        char separator;
        val entry;
        while (file >> entry.index >> separator >> entry.value) {
            if (entry.value != 0) {  // ignore storing if value is 0
                alldata.push_back(entry);
            }
        }
        file.close();
        
    }

    SparseVector operator+(const SparseVector& other)const {//the +operator function
        SparseVector result;
        for (auto& entry : alldata) {
            val new_entry = { entry.index, entry.value };
            for (auto& other_entry : other.alldata) {
                if (entry.index == other_entry.index) {
                    new_entry.value += other_entry.value;
                    break;
                }
            }
            result.alldata.push_back(new_entry);
        }
        for (auto& other_entry : other.alldata) {
            bool found = false;
            for (auto& result_entry : result.alldata) {
                if (other_entry.index == result_entry.index) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                result.alldata.push_back(other_entry);
            }
        }
        return result;
    }

    SparseVector operator-(const SparseVector& other)const {//the -operator function
        SparseVector result;
        for (auto& entry : alldata) {
            val new_entry = { entry.index, entry.value };
            for (auto& other_entry : other.alldata) {
                if (entry.index == other_entry.index) {
                    new_entry.value -= other_entry.value;
                    break;
                }
            }
            result.alldata.push_back(new_entry);
        }
        for (auto& other_entry : other.alldata) {
            bool found = false;
            for (auto& result_entry : result.alldata) {
                if (other_entry.index == result_entry.index) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                result.alldata.push_back(other_entry);
            }
        }
        return result;
    }

    SparseVector operator-() {// to negate the whole vector 
        SparseVector result;

        for (auto& entry : alldata) {
            val new_entry;
            new_entry.value = -entry.value;//let the value negateed
            new_entry.index = entry.index;
            result.alldata.push_back(new_entry);
        }

        return result;
    }

    SparseVector& operator=(const SparseVector& other){
        if (this != &other) { //here to checking for itself 
            this->alldata = other.alldata;
        }
        return *this;
    }

    friend ostream& operator<<(ostream& output, const SparseVector& vec) {// to print cout<<........
        for (const auto& entry : vec.alldata) {
            output << entry.index << ":" << entry.value << " ";
        }
        return output;
    }

    double dot(const SparseVector& other) const {// two argu to make dot(a1,a1) (;
        double dot_product = 0.0;

        // determine the size of the shorter vector
        size_t size = min(alldata.size(), other.alldata.size());

        // multiply corresponding values and sum up
        for (size_t i = 0; i < size; ++i) {
            dot_product += alldata[i].value * other.alldata[i].value;
        }

        // multiply any remaining elements of the longer vector by 0
        for (size_t i = size; i < alldata.size(); ++i) {
            dot_product += alldata[i].value * 0;
        }
        for (size_t i = size; i < other.alldata.size(); ++i) {
            dot_product += other.alldata[i].value * 0;
        }

        return dot_product;
    }
};