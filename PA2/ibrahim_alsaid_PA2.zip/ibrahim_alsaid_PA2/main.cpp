#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include "SparseVector.h"
#include "SparseMatrix.h"
using namespace std;

int main() {
    SparseVector ex("a1.txt");
    cout << ex << endl;
    cout << "\n";

    SparseVector ex1("a2.txt");
    cout << ex1 << endl;
    cout << "\n";

    SparseVector a;
    a = ex + ex1;
    cout << a << endl;
    cout << "\n";

    a = ex - ex1;
    cout << a << endl;
    cout << "\n";

    a = -ex;
    cout << a << endl;
    cout << "\n";

    a = ex;
    cout << a << endl;
    cout << "\n";

    double i = a.dot(ex1);
    cout << i;
    
}
